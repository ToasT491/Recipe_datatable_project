<?php

    // Turn off all error reporting
    error_reporting(0);

    require('dbconnect.php');

    if(isset($_POST['username'])){
        $sql_login= "SELECT username, password ".
                    "FROM tbl_login ".
                    "WHERE username = :username";

        // prepare
        $sql_login = $pdo->prepare($sql_login);

        // sanitize
        $username = filter_var($_POST['username'],FILTER_SANITIZE_STRING);
        // $password = filter_var($_POST['password'],FILTER_SANITIZE_STRING);

        // bind param
        $sql_login->bindparam(":username",$username);
        
        // excecute
        $sql_login->execute();

        // get dataset
        $ds = $sql_login->fetch();

        if($ds['password'] == null){
            echo("<br>Username not found<br>");
        }
        else{
            // store the password from the ds
            $hash_db = $ds['password'];

            // reverse the password and compare
            // password_verify() is the undo process for password_hash()

            if(password_verify($_POST['password'],$hash_db)){
                // instructional purposes only - remove in production
                echo("<br><br>Valid Password<br>");

                // session variable will set a flag to 
                // let the users log into their private pages
                $_SESSION['loginStatus'] = true;

                // Go to the member page
                header('location: memberPage.php');


            }
            else{
                // bad login
                $_SESSION['loginStatus'] = false;

                echo("<br>Invalid Password<br>");

            }

        }

    }

?>

<!-- 
html body for table, uses bottstrap formatting from online
i though it looked nice and was different from the normal table.
-->
<!Doctype html>
<html>
<head>
    <link rel="stylesheet" href="style2.css">
    <meta name="viewport" content="width=device-width,
        initial-scale=1">
    <link href=" https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css " rel="stylesheet">
</head>
<body style="background-color: antiquewhite; margin: 10%;">
<div class="content">
<form action="login.php" method="POST">
<table border="1">
    <tr>
        <td colspan="2">Login</td>
    </tr>
    <tr>
        <td>Username</td>
        <td><input type="text" name="username" size="25" value="jsmith" require></td>
    </tr>
    <tr>
        <td>password</td>
        <td><input type="password" name="password" size="25" value="hotdog" require></td>
    </tr>
    <tr>
        <td></td>
        <td><input type="submit" name="Enter"></td>
    </tr>
</table>
<hr><br>
</form>
<?php include('nav.php'); ?>
</div>
</body>
</html>