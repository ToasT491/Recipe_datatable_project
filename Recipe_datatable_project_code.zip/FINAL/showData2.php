<?php
require("dbconnect.php");

try{
$sql_insert = "INSERT INTO tbl_contact(name,number,email,feedback) 
                VALUES( :name,:number,:email,:feedback)";

// prepare 
$sql_insert = $pdo->prepare($sql_insert);

// sanitize
$recipe = filter_var($_POST['name'],FILTER_SANITIZE_STRING);
$make = filter_var($_POST['number'],FILTER_SANITIZE_NUMBER_INT);
$rating = filter_var($_POST['email'],FILTER_SANITIZE_STRING);
$ingredients = filter_var($_POST['feedback'],FILTER_SANITIZE_STRING);
// bind
$sql_insert->bindParam(":name",$name);
$sql_insert->bindParam(":number",$number);
$sql_insert->bindParam(":email",$email);
$sql_insert->bindParam(":feedback",$feedback);

// execute
$sql_insert->execute();

}
catch(PDOException $pdoerr){
    echo("<h2>Error\n".$pdoerr->getMessage());
}catch(Exception $e){
    echo("<h2>Error\n".$e->getMessage());
}

echo("
<!DOCTYPE html>
<html>
<head>
    <link rel='stylesheet' href='style2.css'>
    <meta name='viewport' content='width=device-width,
        initial-scale=1'>
    <link href=' https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css ' rel='stylesheet'>
</head>
<body style='background-color: antiquewhite; margin: 10%;'>
    <div class='content'>
    <h1>Feedback info</h1>
    <h2>Thank you for submitting your feeback.</h2>
    name: $name<br>
    number: $number<br>
    email: $email<br>
    feedback: $feedback<br>
    <br><hr><br>
    <a href ='default2.php'><button>Go to feedback page</button></a>&nbsp;&nbsp;
    <br><hr><br>
    ");
    include("nav.php");
    echo("
    <hr>
        </div>
</body>
</html>
");

?>