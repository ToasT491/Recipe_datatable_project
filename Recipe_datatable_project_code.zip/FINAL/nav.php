<br>
<a href ="default.php">Home Page</a>&nbsp;&nbsp;
<a href ="default2.php">Feedback and contact Page</a>&nbsp;&nbsp;
<a href="newUser.php">New User</a>&nbsp;&nbsp;
<a href="login.php">Login</a>&nbsp;&nbsp;
<a href="memberPage.php">Member Page</a>&nbsp;&nbsp;
<a href="logout.php">Log Out</a><br>
<br>