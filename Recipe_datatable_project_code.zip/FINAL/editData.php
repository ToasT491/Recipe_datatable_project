<?php
    require('dbconnect.php');

    if(!empty($_POST['recipe'])){


        // update query
        $sql_update="UPDATE tbl_final "
                    ."SET recipe = :recipe, "
                    ."make = :make, "
                    ."rating = :rating, "
                    ."ingredients = :ingredients, "
                    ."amount = :amount, "
                    ."origin = :origin "
                    ."WHERE pk = :pk";

        //prepare our statement
        $sql_update = $pdo->prepare($sql_update);

        //sanitize info
        $recipe = filter_var($_POST['recipe'],FILTER_SANITIZE_STRING);
        $make = filter_var($_POST['make'],FILTER_SANITIZE_NUMBER_INT);
        $rating = filter_var($_POST['rating'],FILTER_SANITIZE_STRING);
        $ingredients = filter_var($_POST['ingredients'],FILTER_SANITIZE_STRING);
        $amount = filter_var($_POST['amount'],FILTER_SANITIZE_NUMBER_INT);
        $origin = filter_var($_POST['origin'],FILTER_SANITIZE_STRING);
        $pk = filter_var($_POST['pk'],FILTER_SANITIZE_STRING);

        //bind param
        $sql_update->bindParam(":recipe",$recipe);
        $sql_update->bindParam(":make",$make);
        $sql_update->bindParam(":rating",$rating);
        $sql_update->bindParam(":ingredients",$ingredients);
        $sql_update->bindParam(":amount",$amount);
        $sql_update->bindParam(":origin",$origin);
        //because of the where statement
        $sql_update->bindParam(":pk",$pk);

        //execute
        $sql_update->execute();

        //switch page
        header("Location: displayEdit.php");
    }

    $sql_editdata ="SELECT * FROM tbl_final ".
                    "WHERE pk= ".$_SESSION['pk'];

    $ds_editData= $pdo-> query("$sql_editdata");

    $row_edit = $ds_editData->fetch();

?>

<!DOCTYPE html>
<html>
<head>
    <title>Data editing page</title>
    <link rel="stylesheet" href="style2.css">
    <meta name="viewport" content="width=device-width,
        initial-scale=1">
    <link href=" https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css " rel="stylesheet">
</head>
<body style="background-color: antiquewhite; margin: 10%;">
    <div class="content">
        <H2>Edit Data</H2>
        <form method="POST" action="editData.php"
            onsubmit="return confirm('Are you sure')">
        <table border="1">
            <thead>
                <th colspan="2">Recipe info</th>
            </thead>
            <tbody>
                <tr>
                    <td>Recipe</td>
                    <td><input type="text" name="recipe"
                        value="<?php echo($row_edit['recipe']);?>"
                        size="20" required></td>
                </tr>
                <tr>
                    <td>How many it feeds</td>
                    <td><input type="number" name="make"
                        value="<?php echo($row_edit['make']);?>"
                        size="20"></td>
                </tr>
                <tr>
                    <td>Rating 1-10</td>
                    <td><input type="text" name="rating"
                        value="<?php echo($row_edit['rating']);?>"
                        size="20"></td>
                </tr>
                <tr>
                    <td>ingredients</td>
                    <td><input type="text" name="ingredients"
                        value="<?php echo($row_edit['ingredients']);?>"
                        size="20"></td>
                </tr>
                <tr>
                    <td>Amount</td>
                    <td><input type="number" name="amount"
                        value="<?php echo($row_edit['amount']);?>"
                        size="20"></td>
                </tr>
                <tr>
                    <td>Origin</td>
                    <td><input type="text" name="origin"
                        value="<?php echo($row_edit['origin']);?>"
                        size="20"></td>
                </tr>
                <tr>
                    <td>Record Id: <?php echo($row_edit['pk']); ?>
                        <input type="hidden" name="pk" value="<?php echo($row_edit['pk']); ?>">
                    </td>
                    <td><input type="submit" value="Enter"></td>
                </tr>   
            </tbody>

        </table>
        </form>
        <?php
            include('nav.php');
        ?>
        <br><hr>
        <h3>Memebers Only Navigation</h3>
        <?php
            include("nav2.php");
        ?>
        <br><br><br>
    </div>
</body>
</html>