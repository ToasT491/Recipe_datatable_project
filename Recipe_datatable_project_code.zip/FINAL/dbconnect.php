<?php

try{

    $host = "127.0.0.1";
    $user = "root";
    $pw = "";

    // created a pdo object  
    $pdo = new PDO('mysql:host=127.0.0.1;dbname=final_project',$user,$pw);

    // lets setup some attributes for the object
    $pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

    // only for educational purposes
    //$dbstatus = "Good database connection";
    //echo($dbstatus.'<br><hr><br>');
}
catch(PDOException $ep){
    $dbstatus = "Database connection failed<br>".
                    $ep->getMessage();

    // for development purposes
    echo($dbstatus.'<br><hr><br>');
    die();
}
catch(Exception $e){
    $dbstatus = "Database connection failed<br>".
                    $e->getMessage();

    echo($dbstatus.'<br><hr><br>');
    die();
}

session_start();

?>