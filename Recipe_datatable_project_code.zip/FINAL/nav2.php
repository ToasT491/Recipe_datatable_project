<br>
<a style="color: red;" href="showData.php">Show info</a>&nbsp;&nbsp;
<a style="color: red;" href ="displayEdit.php">Data table</a>&nbsp;&nbsp;
<br>