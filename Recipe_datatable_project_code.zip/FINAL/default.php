<?php
    $theYear = date('Y');
?>
<!-- 
html body for table, uses bottstrap formatting from online
i though it looked nice and was different from the normal table.
-->
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
    <meta name="viewport" content="width=device-width,
        initial-scale=1">
    <link href=" https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css " rel="stylesheet">
</head>
    <body style="background-color: antiquewhite; margin: 10%;">
        <div class="content">
            <h1>Welcome to the final project.</h1>
                <p>This final project combines databases, table editing and login features</p>
                <p>This project is making a working login site where you can enter your</p>
                <p>favorite recipes into a table to keep them in an easy to access space.</p>
            <h2>Below is the user sign in and login.</h2>
            <p>You can create an account to access the recipe input area.</p>
            <p>Once logged in you will gain access to another set of navigation links only accessable to members.</p>
        </body>
        <br><hr>
    </div>
    <body2>

        <h4>User sign in/login</h4>
        <a href="newUser.php">New User</a><br>
        <a href="login.php">Login</a><br>
        <a href="memberPage.php">Member Page</a><br>
        <a href="logout.php">Log Out</a><br>
        <br><hr>
        <?php
        include("nav.php");
        ?>
    </body2>

    <footer>
                <p>&copy; <?php echo($theYear) ?></p>
    </footer>

</html>