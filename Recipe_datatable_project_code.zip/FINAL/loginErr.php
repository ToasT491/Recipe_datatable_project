<?php

    require('dbconnect.php');

?>

<!Doctype html>
<html>
<head>
    <link rel="stylesheet" href="style2.css">
    <meta name="viewport" content="width=device-width,
        initial-scale=1">
    <link href=" https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css " rel="stylesheet">
</head>
<body style="background-color: antiquewhite; margin: 10%;">
<div class="content">
    <h1>Login Error</h1>

    <?php echo($_SESSION['logerr_message']); ?>
    <br>

    <a href="newUser.php">Create Account</a>

</div>
</body>
</html>