<?php
    session_start();
    // unset/delete the loginstatus
    unset($_SESSION['loginStatus']);
    // redirect to home page
    header('location: default.php');
?>