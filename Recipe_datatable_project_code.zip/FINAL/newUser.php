<?php

    //connection string
    require('dbconnect.php');

    if(isset($_POST['username'])){
        try{
        $pwd = $_POST['password'];

        // 1. setup sqlstatement
        $sql = "INSERT INTO tbl_login("
                ."fname,lname,username,password) "
                ." VALUES(:fname,:lname,:username,:password)";

        // 2. prepare
        $sql = $pdo->prepare($sql);

        // 3. sanitize
        $fname = filter_var($_POST['fname'],FILTER_SANITIZE_STRING);
        $lname = filter_var($_POST['lname'],FILTER_SANITIZE_STRING);
        $username = filter_var($_POST['username'],FILTER_SANITIZE_STRING);
        $password = filter_var($_POST['password'],FILTER_SANITIZE_STRING);

        // ************ Password *******************
            $password = password_hash($pwd,PASSWORD_DEFAULT);
        // *****************************************

        // 4 bind make sure names are ALL correct otherwise it wont run 
        $sql->bindparam(":fname",$fname);
        $sql->bindparam(":lname",$lname);
        $sql->bindparam(":username",$username);
        $sql->bindparam(":password",$password);
    
        // 5 execute sql statement
        $sql->execute();

        echo('<p>User was successfully added</p>');
        echo('
        <a href ="default.php"><button>Back to Default</button></a>&nbsp;&nbsp;
        ');
        }
        catch(PDOException $ee){
            echo($ee->getMessage());
            echo("<br><br>");
            
            if($ee->getCode()){
                $_SESSION['logerr_message'] = "Please select different Username";
                header('location: loginErr.php');

            }
        }

    }
    else{
        echo('
        <!Doctype html>
        <html>
        <head>
    <link rel="stylesheet" href="style2.css">
    <meta name="viewport" content="width=device-width,
        initial-scale=1">
    <link href=" https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css " rel="stylesheet">
    </head>
        <body style="background-color: antiquewhite; margin: 10%;">
        <div class="content">
            <h1>New User</h1>
            <form method="POST" action="newUser.php">
            <table border="1">
                <tr>
                    <td>First Name</td>
                    <td><input type="text" name="fname"size="25" value="Joe"></td>
                </tr>
                <tr>
                    <td>Last Name</td>
                    <td><input type="text" name="lname"size="25" value="Smith"></td>
                </tr>
                <tr>
                    <td>User Name</td>
                    <td><input type="text" name="username"
                            size="25" value="jsmith" require></td>
                </tr>
                <tr>
                    <td>Password</td>
                    <td><input type="password" name="password"
                            size="25" value="hotdog" require></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" value="Enter"></td>
                </tr>
                </table>
            </form>
            <br><hr>
        ');
        include('nav.php');
        echo('        
        </div>
        </body>
        </html>
        ');
    }
?>