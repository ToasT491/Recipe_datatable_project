<?php
error_reporting(0);
require("dbconnect.php");

try{
$sql_insert = "INSERT INTO tbl_final(recipe,make,rating,ingredients,amount,origin) 
                VALUES( :recipe,:make,:rating,:ingredients,:amount,:origin)";
// prepare 
$sql_insert = $pdo->prepare($sql_insert);

// sanitize
$recipe = filter_var($_POST['recipe'],FILTER_SANITIZE_STRING);
$make = filter_var($_POST['make'],FILTER_SANITIZE_NUMBER_INT);
$rating = filter_var($_POST['rating'],FILTER_SANITIZE_STRING);
$ingredients = filter_var($_POST['ingredients'],FILTER_SANITIZE_STRING);
$amount = filter_var($_POST['amount'],FILTER_SANITIZE_NUMBER_INT);
$origin = filter_var($_POST['origin'], FILTER_SANITIZE_STRING);

// bind
$sql_insert->bindParam(":recipe",$recipe);
$sql_insert->bindParam(":make",$make);
$sql_insert->bindParam(":rating",$rating);
$sql_insert->bindParam(":ingredients",$ingredients);
$sql_insert->bindParam(":amount",$amount);
$sql_insert->bindParam(":origin",$origin);
// execute
$sql_insert->execute();

}
catch(PDOException $pdoerr){
    //echo("<h2>Error\n".$pdoerr->getMessage());
}catch(Exception $e){
    //echo("<h2>Error\n".$e->getMessage());
}

echo("
<!DOCTYPE html>
<html>
<head>
    <link rel='stylesheet' href='style2.css'>
    <meta name='viewport' content='width=device-width,
        initial-scale=1'>
    <link href=' https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css ' rel='stylesheet'>
</head>
<body style='background-color: antiquewhite; margin: 10%;'>
    <div class='content'>
    <h1>Recipe Information confirmation</h1>
    recipe: $recipe<br>
    make: $make<br>
    rating: $rating<br>
    ingredients: $ingredients<br>
    amount: $amount<br>
    origin: $origin<br>
    <br><hr><br>
    <a href ='displayEdit.php'><button>Go to table page</button></a>&nbsp;&nbsp;
    <br><hr><br>
    ");
    include("nav.php");
    echo("
    <hr>
    <h3>Memebers Only Navigation</h3>
    ");
        include("nav2.php");
    echo("
        </div>
</body>
</html>
");

?>