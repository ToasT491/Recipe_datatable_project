<?php
    require('dbconnect.php');


    if(isset($_POST)){
        if(!empty($_POST['action'])){
            if($_POST['action']=='Delete'){
            $pk = filter_var($_POST['pk'],FILTER_SANITIZE_STRING);
            $sql_deleteDog = "DELETE FROM tbl_final WHERE pk=".$pk;
            $pdo-> exec($sql_deleteDog);

            unset($_POST['action']);
            }
            if($_POST['action']== 'Edit');
                $_SESSION['pk']= filter_var($_POST['pk'],FILTER_SANITIZE_NUMBER_INT);
                header("Location: editData.php");
        }
    }

    $sql_selectEdit = "SELECT * FROM tbl_final ORDER BY recipe";
    $ds = $pdo->query($sql_selectEdit);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Info display</title>
    <link rel="stylesheet" href="style2.css">
    <meta name="viewport" content="width=device-width,
        initial-scale=1">
    <link href=" https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css " rel="stylesheet">
</head>
<body style="background-color: antiquewhite; margin: 10%;">
    <div class="content">
        <table border="1">
            <tr>
                <th>Recipe</th>
                <th>Make</th>
                <th>Rating 1-10</th>
                <th>Ingredients</th>
                <th>Amount</th>
                <th>Origin</th>
                <th></th>
            </tr>
            <?php
                while($row = $ds->fetch())
                {
                    echo('<tr>'
                    .'<td>'.$row['recipe'].'</td>'
                    .'<td>'.$row['make'].'</td>'
                    .'<td>'.$row['rating'].'</td>'
                    .'<td>'.$row['ingredients'].'</td>'
                    .'<td>'.$row['amount'].'</td>'
                    .'<td>'.$row['origin'].'</td>'
                    .'<td><form method="POST" action="displayEdit.php"
                            onsubmit="return confirm('."'".'Are You Sure?'."')".'">
                            <input type="hidden" name="pk" value="'.$row['pk'].'">'
                            .'<input type="submit" value="Edit" name="action" >&nbsp;&nbsp;'
                            .'<input type="submit" value="Delete" name="action" >&nbsp;&nbsp;'
                            .'</form></td></tr>'
                    );
                }
            ?>
        </table>
    </div>
    <?php
        include("nav.php");
    ?>
    <br><hr>
        <h3>Memebers Only Navigation</h3>
        <?php
            include("nav2.php");
        ?>
        <br><br><br>
</body>
</html>