<?php
    $theYear = date('Y');
?>
<!-- 
html body for table, uses bottstrap formatting from online
i though it looked nice and was different from the normal table.
-->
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style2.css">
    <meta name="viewport" content="width=device-width,
        initial-scale=1">
    <link href=" https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css " rel="stylesheet">
</head>
    <body style="background-color: antiquewhite; margin: 10%;">
        <div class="content">
            <h1>This is the Feedback and contact info page.</h1>
                <p>Please enter your contact information so we can respond back to you</p>
                <p>about your feedback. all feedback is welcome, thank you.</p>
        <br><hr>
<div style="margin:auto" style="margin-right: auto;" class="content">
<form action="showData2.php" method="POST">
    <div class="mb-3">
        <label class="form-label">First and last name</label>
        <input type="text" class="form-control"
        placeholder="John Smith"
        name="name" autocomplete="off">
    </div>
    <div class="mb-3">
        <label class="form-label">Phone Number</label>
        <input type="number" class="form-control"
        placeholder="000-000-0000"
        name="number" autocomplete="off">
    </div>
    <div class="mb-3">
        <label class="form-label">email</label>
        <input type="email" class="form-control"
        placeholder="example@email.com"
        name="email" autocomplete="off">
    </div>
    <div class="mb-3">
        <label class="form-label">Feedback</label>
        <input type="text" class="form-control"
        placeholder="needs improvement here..."
        name="feedback" autocomplete="off">
    </div>
    <div class="mb-3">
        <input type="submit" class="form-control"
        value="Submit"
        name="Submit" autocomplete="off">
    </div>
</form>
<br><hr><br>
<?php
    include("nav.php");
?>
</div>
</body>
<footer>
                <p>&copy; <?php echo($theYear) ?></p>
    </footer>
    </div>
</html>