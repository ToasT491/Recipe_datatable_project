<?php

    session_start();

    if(!isset($_SESSION['loginStatus']) || $_SESSION['loginStatus']== false){
        header('location:default.php');
    }
?>

<!Doctype html>
<html>
<head>
    <link rel="stylesheet" href="style2.css">
    <meta name="viewport" content="width=device-width,
        initial-scale=1">
    <link href=" https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css " rel="stylesheet">
</head>
<body style="background-color: antiquewhite; margin: 10%;">
    <h1>Welcome to the Memebers only page</h1>
    <p>Here is where you can input your information and access it on another page</p>
<div style="margin:auto" class="content">
<form action="showData.php" method="POST">
    <div class="mb-3">
        <label class="form-label">Recipe Name</label>
        <input type="text" class="form-control"
        placeholder="Chicken"
        name="recipe" autocomplete="off">
    </div>
    <div class="mb-3">
        <label class="form-label">Time to make(min)</label>
        <input type="number" class="form-control"
        placeholder="00"
        name="make" autocomplete="off">
    </div>
    <div class="mb-3">
        <label class="form-label">Rating 1-10</label>
        <input type="Text" class="form-control"
        placeholder="7, little dry"
        name="rating" autocomplete="off">
    </div>
    <div class="mb-3">
        <label class="form-label">Ingredients</label>
        <input type="text" class="form-control"
        placeholder="chicken, flour ..."
        name="ingredients" autocomplete="off">
    </div>
    <div class="mb-3">
        <label class="form-label">how many it serves</label>
        <input type="number" class="form-control"
        placeholder="4"
        name="amount" autocomplete="off">
    </div>
    <div class="mb-3">
        <label class="form-label">Origin</label>
        <input type="text" class="form-control"
        placeholder="Italy"
        name="origin" autocomplete="off">
    </div>
    <div class="mb-3">
        <input type="submit" class="form-control"
        value="Submit"
        name="Submit" autocomplete="off">
    </div>
</form>
<hr>
<p>Through the navigation you can access other pages that only memebers can access. </p>
<hr>
<?php
    include("nav.php");
?>
<hr>
<h3>Memebers Only Navigation</h3>
<?php
    include("nav2.php");
?>
<br><br>
</div>
</body>
</html>